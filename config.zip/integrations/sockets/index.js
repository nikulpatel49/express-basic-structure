const cryptoDeposit = require("./cryptoDeposit");

module.exports.init = () => {
	cryptoDeposit.init();
};
