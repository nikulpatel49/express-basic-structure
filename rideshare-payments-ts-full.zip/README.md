# Rideshare Payments (TypeScript)

This repository contains a TypeScript (Node.js + Express + Mongoose) implementation
for Stripe payment flows (Flow A: preauth -> capture; Flow B: immediate charge).

Follow the README and the main document to set environment variables and run.
