import express from 'express';
import stripe from '../services/stripeClient';
import { Booking } from '../models/Booking';
import { User } from '../models/User';
import { Driver } from '../models/Driver';
import { recordLedger } from '../services/ledgerService';
import { generateKey } from '../services/idempotency';
import { PLATFORM_COMMISSION_PERCENT, CURRENCY } from '../config';

const router = express.Router();

// Create pre-auth PaymentIntent (manual capture)
router.post('/:id/preauth', async (req, res) => {
  const bookingId = req.params.id;
  const { payment_method_id } = req.body;
  const booking = await Booking.findById(bookingId).populate('rider');
  if (!booking) return res.status(404).json({ error: 'Booking not found' });

  const user = await User.findById(booking.rider);
  if (!user) return res.status(404).json({ error: 'User not found' });

  if (!user.stripeCustomerId) {
    const cus = await stripe.customers.create({ email: user.email, name: user.name, metadata: { userId: user._id.toString() } });
    user.stripeCustomerId = cus.id;
    await user.save();
  }

  const estimated = booking.estimatedFare;
  try {
    const idempotencyKey = generateKey('preauth', bookingId);
    const pi = await stripe.paymentIntents.create({
      amount: estimated,
      currency: CURRENCY,
      customer: user.stripeCustomerId,
      payment_method: payment_method_id,
      capture_method: 'manual',
      confirm: true,
      description: `Preauth for booking ${bookingId}`,
      metadata: { bookingId }
    }, { idempotencyKey });

    booking.paymentIntentId = pi.id;
    booking.authorizedAmount = pi.amount;
    booking.paymentStatus = pi.status;
    booking.authExpiresAt = new Date(Date.now() + (7 * 24 * 3600 * 1000));
    await booking.save();

    await recordLedger({ type: 'charge', amount: pi.amount_capturable ?? 0, currency: pi.currency, referenceId: pi.id, bookingId: booking._id, metadata: { status: pi.status } });

    res.json({ paymentIntent: pi });
  } catch (err: any) {
    console.error('preauth error', err);
    res.status(400).json({ error: err.message });
  }
});

// Capture endpoint (called when trip completes)
router.post('/:id/capture', async (req, res) => {
  const bookingId = req.params.id;
  const booking = await Booking.findById(bookingId).populate('driver rider');
  if (!booking) return res.status(404).json({ error: 'Booking not found' });
  if (!booking.paymentIntentId) return res.status(400).json({ error: 'No preauth present' });

  const finalFare = req.body.finalFare;
  try {
    const idempotencyKey = generateKey('capture', bookingId);
    const cap = await stripe.paymentIntents.capture(booking.paymentIntentId!, { amount_to_capture: finalFare }, { idempotencyKey });

    await recordLedger({ type: 'charge', amount: finalFare, currency: cap.currency, referenceId: cap.id, bookingId: booking._id });

    const commissionPercent = PLATFORM_COMMISSION_PERCENT;
    const commission = Math.round(finalFare * (commissionPercent / 100));
    const driverAmount = finalFare - commission;

    const driver = await Driver.findById(booking.driver);
    if (!driver || !driver.stripeAccountId) {
      booking.paymentStatus = 'succeeded';
      booking.finalFare = finalFare;
      booking.commission = commission;
      await booking.save();

      await recordLedger({ type: 'fee', amount: commission, currency: cap.currency, bookingId: booking._id, referenceId: cap.id });

      return res.json({ success: true, captured: cap, transfer: null, note: 'Driver not onboarded; funds retained' });
    }

    const transferKey = generateKey('transfer', bookingId);
    const transfer = await stripe.transfers.create({ amount: driverAmount, currency: cap.currency, destination: driver.stripeAccountId, metadata: { bookingId: booking._id.toString(), paymentIntentId: cap.id } }, { idempotencyKey: transferKey });

    await recordLedger({ type: 'transfer', amount: driverAmount, currency: cap.currency, referenceId: transfer.id, bookingId: booking._id });
    await recordLedger({ type: 'fee', amount: commission, currency: cap.currency, bookingId: booking._id, referenceId: cap.id });

    booking.finalFare = finalFare;
    booking.commission = commission;
    booking.paymentStatus = 'succeeded';
    booking.transfers.push({ id: transfer.id, amount: driverAmount, status: transfer.status });
    booking.captureAt = new Date();
    await booking.save();

    res.json({ success: true, captured: cap, transfer });
  } catch (err: any) {
    console.error('capture error', err);
    booking.paymentStatus = 'failed';
    await booking.save();
    res.status(402).json({ error: err.message });
  }
});

// Immediate charge (Flow B)
router.post('/:id/charge', async (req, res) => {
  const bookingId = req.params.id;
  const booking = await Booking.findById(bookingId).populate('rider driver');
  if (!booking) return res.status(404).json({ error: 'Booking not found' });

  const user = await User.findById(booking.rider);
  if (!user) return res.status(404).json({ error: 'User not found' });

  const amount = booking.estimatedFare;
  try {
    const idempotencyKey = generateKey('charge', bookingId);
    const pi = await stripe.paymentIntents.create({ amount, currency: CURRENCY, customer: user.stripeCustomerId, payment_method: req.body.payment_method_id, confirm: true, description: `Charge for booking ${bookingId}`, metadata: { bookingId } }, { idempotencyKey });

    if (pi.status === 'requires_action') return res.json({ requiresAction: true, clientSecret: pi.client_secret });

    booking.paymentIntentId = pi.id;
    booking.finalFare = amount;
    booking.paymentStatus = pi.status;
    await booking.save();

    res.json({ success: true, paymentIntent: pi });
  } catch (err: any) {
    console.error('charge error', err);
    res.status(400).json({ error: err.message });
  }
});

export default router;
