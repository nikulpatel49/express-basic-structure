import express from 'express';
import stripe from '../services/stripeClient';
import { STRIPE_WEBHOOK_SECRET } from '../config';
import { Booking } from '../models/Booking';
import { recordLedger } from '../services/ledgerService';

const router = express.Router();

router.post('/', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'] as string | undefined;
  if (!sig) return res.status(400).send('Missing signature');

  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, STRIPE_WEBHOOK_SECRET);
  } catch (err: any) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  try {
    switch (event.type) {
      case 'payment_intent.succeeded': {
        const pi = event.data.object as Stripe.PaymentIntent;
        const booking = await Booking.findOne({ paymentIntentId: pi.id });
        if (booking) {
          booking.paymentStatus = 'succeeded';
          booking.finalFare = booking.finalFare ?? pi.amount;
          await booking.save();
          await recordLedger({ type: 'charge', amount: pi.amount, currency: pi.currency, referenceId: pi.id, bookingId: booking._id });
        }
        break;
      }
      case 'payment_intent.payment_failed': {
        const pi = event.data.object as Stripe.PaymentIntent;
        const booking = await Booking.findOne({ paymentIntentId: pi.id });
        if (booking) {
          booking.paymentStatus = 'failed';
          await booking.save();
        }
        break;
      }
      case 'charge.refunded': {
        const charge = event.data.object as any;
        const booking = await Booking.findOne({ paymentIntentId: charge.payment_intent });
        if (booking) {
          await recordLedger({ type: 'refund', amount: charge.amount_refunded, currency: charge.currency, referenceId: charge.id, bookingId: booking._id });
          booking.paymentStatus = 'refunded';
          await booking.save();
        }
        break;
      }
      default:
        break;
    }
  } catch (err) {
    console.error('Webhook processing failed', err);
  }

  res.status(200).json({ received: true });
});

export default router;
