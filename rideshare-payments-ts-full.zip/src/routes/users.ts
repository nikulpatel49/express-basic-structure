import express from 'express';
import { User } from '../models/User';
import stripe from '../services/stripeClient';
import { generateKey } from '../services/idempotency';

const router = express.Router();

// create or return stripe customer for user
router.post('/:id/create-customer', async (req, res) => {
  const userId = req.params.id;
  const user = await User.findById(userId);
  if (!user) return res.status(404).json({ error: 'User not found' });

  if (user.stripeCustomerId) return res.json({ stripeCustomerId: user.stripeCustomerId });

  const cus = await stripe.customers.create({ email: user.email, name: user.name, metadata: { userId: user._id.toString() } });
  user.stripeCustomerId = cus.id;
  await user.save();
  res.json({ stripeCustomerId: cus.id });
});

export default router;
