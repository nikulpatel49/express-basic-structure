import mongoose, { Document, Schema } from 'mongoose';

export interface ITransferRecord { id: string; amount: number; status: string }

export interface IBooking extends Document {
  rider: mongoose.Types.ObjectId;
  driver?: mongoose.Types.ObjectId;
  status: 'requested'|'accepted'|'started'|'completed'|'cancelled';
  estimatedFare: number;
  authorizedAmount?: number;
  finalFare?: number;
  paymentIntentId?: string;
  paymentStatus?: string;
  commission?: number;
  transfers: ITransferRecord[];
  authExpiresAt?: Date;
}

const TransferRecordSchema = new Schema<ITransferRecord>({ id: String, amount: Number, status: String }, { _id: false });

const BookingSchema = new Schema<IBooking>({
  rider: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  driver: { type: Schema.Types.ObjectId, ref: 'Driver' },
  status: { type: String, default: 'requested' },
  estimatedFare: { type: Number, required: true },
  authorizedAmount: Number,
  finalFare: Number,
  paymentIntentId: String,
  paymentStatus: String,
  commission: Number,
  transfers: [TransferRecordSchema],
  authExpiresAt: Date
}, { timestamps: true });

export const Booking = mongoose.model<IBooking>('Booking', BookingSchema);
