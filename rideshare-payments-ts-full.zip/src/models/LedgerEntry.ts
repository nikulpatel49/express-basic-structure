import mongoose, { Document, Schema } from 'mongoose';

export interface ILedger extends Document {
  type: 'charge'|'transfer'|'refund'|'fee'|'adjustment';
  amount: number;
  currency: string;
  referenceId?: string;
  bookingId?: mongoose.Types.ObjectId;
  metadata?: Record<string, any>;
}

const LedgerSchema = new Schema<ILedger>({
  type: { type: String, required: true },
  amount: { type: Number, required: true },
  currency: { type: String, default: 'gbp' },
  referenceId: String,
  bookingId: { type: Schema.Types.ObjectId, ref: 'Booking' },
  metadata: Schema.Types.Mixed
}, { timestamps: true });

export const LedgerEntry = mongoose.model<ILedger>('LedgerEntry', LedgerSchema);
