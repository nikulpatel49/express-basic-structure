import mongoose, { Document, Schema } from 'mongoose';

export interface IDriver extends Document {
  name: string;
  email: string;
  stripeAccountId?: string;
  payoutSchedule?: { interval: string; delayDays: number };
}

const DriverSchema = new Schema<IDriver>({
  name: String,
  email: String,
  stripeAccountId: String,
  payoutSchedule: { interval: String, delayDays: Number }
}, { timestamps: true });

export const Driver = mongoose.model<IDriver>('Driver', DriverSchema);
