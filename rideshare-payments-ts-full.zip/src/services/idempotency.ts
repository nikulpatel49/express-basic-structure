export function generateKey(prefix: string, id: string) {
  return `${prefix}:${id}`;
}
