import { LedgerEntry } from '../models/LedgerEntry';

export async function recordLedger(entry: Partial<any>) {
  return LedgerEntry.create(entry);
}
