import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';
import bookingsRouter from './routes/bookings';
import usersRouter from './routes/users';
import webhooksRouter from './routes/webhooks';

dotenv.config();

const app = express();

// Security middlewares
app.use(helmet());
app.use(cors());
app.use(express.json());

// Rate limiting for sensitive endpoints
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 120 });
app.use(limiter);

// Routes
app.use('/api/bookings', bookingsRouter);
app.use('/api/users', usersRouter);
// webhook route uses raw body parsing in route file
app.use('/webhook', webhooksRouter);

// health
app.get('/health', (req, res) => res.json({ ok: true }));

export default app;
