import UserModel, { IUser } from '../models/user.model';

export const createUser = (data: Partial<IUser>) => UserModel.create(data);
export const findUserByEmail = (email?: string) => UserModel.findOne({ email }).exec();
export const findAllUsers = () => UserModel.find().exec();
export const findUserById = (id: string) => UserModel.findById(id).exec();
