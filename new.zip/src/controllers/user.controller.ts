import { Request, Response } from 'express';
import * as userService from '../services/user.service';
import { sendSuccess } from '../utils/response.util';

export const createUser = async (req: Request, res: Response) => {
  const user = await userService.createUser(req.body);
  sendSuccess(res, user, 201, 'User created');
};

export const getUsers = async (req: Request, res: Response) => {
  const users = await userService.getUsers();
  sendSuccess(res, users);
};

export const getUserById = async (req: Request, res: Response) => {
  const user = await userService.getUserById(req.params.id);
  sendSuccess(res, user);
};
