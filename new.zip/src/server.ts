import env from './config/env';
import connectDB from './config/db';
import logger from './config/logger';
import app from './app';

// start otel early
import './config/otel';

(async () => {
  try {
    await connectDB();
    const port = env.PORT;
    app.listen(port, () => {
      logger.info(`🚀 Server running on port ${port}`);
    });
  } catch (err) {
    logger.error('Failed to start server', err as Error);
    process.exit(1);
  }
})();
