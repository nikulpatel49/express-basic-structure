import { Response } from 'express';

export const sendSuccess = (res: Response, data: any, status = 200, message = 'Success') => {
  res.status(status).json({ success: true, message, data });
};
