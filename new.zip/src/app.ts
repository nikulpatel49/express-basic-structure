import express from 'express';
import morgan from 'morgan';
import userRoutes from './routes/user.routes';
import { errorHandler, AppError } from './middlewares/error.middleware';

const app = express();

app.use(express.json());
app.use(morgan('dev'));

app.use('/api/users', userRoutes);

// 404
app.all('*', (req, res, next) => {
  next(new AppError(`Can't find ${req.originalUrl} on this server`, 404));
});

app.use(errorHandler);

export default app;
