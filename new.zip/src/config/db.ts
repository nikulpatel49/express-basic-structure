import mongoose from 'mongoose';
import logger from './logger';
import env from './env';

const connectDB = async (): Promise<void> => {
  try {
    await mongoose.connect(env.MONGO_URI, {
      // mongoose v7 uses these options by default, kept for clarity
    } as mongoose.ConnectOptions);
    logger.info('✅ MongoDB connected');
  } catch (err) {
    logger.error('❌ MongoDB connection error', err as Error);
    throw err;
  }
};

export default connectDB;
