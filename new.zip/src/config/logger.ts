import pino from 'pino';
import { context, trace } from '@opentelemetry/api';

const logger = pino({
  level: process.env.LOG_LEVEL || 'info',
  timestamp: pino.stdTimeFunctions.isoTime,
  formatters: {
    log(object) {
      try {
        const span = trace.getSpan(context.active());
        if (span) {
          // attach traceId if present
          (object as any).traceId = span.spanContext().traceId;
        }
      } catch (e) {
        // ignore
      }
      return object;
    }
  }
});

export default logger;
