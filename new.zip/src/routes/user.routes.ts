import { Router } from 'express';
import * as userController from '../controllers/user.controller';
import { asyncHandler } from '../middlewares/asyncHandler';

const router = Router();

router.post('/', asyncHandler(userController.createUser));
router.get('/', asyncHandler(userController.getUsers));
router.get('/:id', asyncHandler(userController.getUserById));

export default router;
