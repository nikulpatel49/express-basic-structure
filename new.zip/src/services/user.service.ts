import * as userRepo from '../repositories/user.repo';
import { AppError } from '../middlewares/error.middleware';
import { IUser } from '../models/user.model';

export const createUser = async (data: Partial<IUser>): Promise<IUser> => {
  const existing = await userRepo.findUserByEmail(data.email as string);
  if (existing) throw new AppError('Email already in use', 400);
  return userRepo.createUser(data as any);
};

export const getUsers = async (): Promise<IUser[]> => {
  return userRepo.findAllUsers();
};

export const getUserById = async (id: string): Promise<IUser> => {
  if (!/^[0-9a-fA-F]{24}$/.test(id)) throw new AppError('Invalid ID', 400);
  const user = await userRepo.findUserById(id);
  if (!user) throw new AppError('User not found', 404);
  return user;
};
