const { io } = require("socket.io-client");
const socket = io("http://localhost:4000/rider", { path: "/ws" });

socket.on("connect", () => {
  console.log("👤 Rider connected", socket.id);
  socket.emit("rider:connect", { riderId: "rider1" });
  socket.emit("ride:join", { driverId: "driver1" });
});

socket.on("driver:location:live", (loc) => {
  console.log("📍 Driver Location Update:", loc);
});
