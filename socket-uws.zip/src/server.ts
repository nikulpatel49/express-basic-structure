import { App } from "uWebSockets.js";
import { Server } from "socket.io";
import { createAdapter } from "@socket.io/redis-adapter";
import msgpackParser from "socket.io-msgpack-parser";
import { pubClient, subClient } from "./config/redis";
import { env } from "./config/env";
import driverGateway from "./gateways/driver.gateway";
import riderGateway from "./gateways/rider.gateway";

const uwsApp = App();

const io = new Server({
  path: "/ws",
  parser: msgpackParser,
  serveClient: false,
  transports: ["websocket"]
});

io.adapter(createAdapter(pubClient, subClient));

driverGateway(io.of("/driver"));
riderGateway(io.of("/rider"));

uwsApp.ws("/*", {
  compression: 0,
  maxPayloadLength: 16 * 1024 * 1024,
  idleTimeout: 30
});

uwsApp.any("/*", (res, req) => {
  res.end("🚀 Cab Booking Socket Server Running");
});

uwsApp.listen(Number(env.PORT), (token) => {
  if (token) {
    console.log(`🔥 uWebSockets.js server listening on port ${env.PORT}`);
  } else {
    console.error("❌ Failed to start uWS server");
  }
});

io.attachApp(uwsApp);
