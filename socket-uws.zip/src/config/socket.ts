// not needed anymore because we bind socket.io directly to uWS in server.ts
