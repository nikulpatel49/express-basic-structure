import { Socket } from "socket.io";
import { onDriverAuth } from "./auth.events";
import { onDriverLocationUpdate } from "./location.events";
import { onRideStart, onRideComplete } from "./ride.events";

export const onDriverConnection = (socket: Socket) => {
  console.log("🚖 Driver connected:", socket.id);

  socket.on("driver:connect", (payload) => onDriverAuth(socket, payload));
  socket.on("driver:location:update", (payload) => onDriverLocationUpdate(socket, payload));
  socket.on("ride:start", () => onRideStart(socket));
  socket.on("ride:complete", () => onRideComplete(socket));
};
