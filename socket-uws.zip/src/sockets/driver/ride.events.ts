import { Socket } from "socket.io";

export const onRideStart = (socket: Socket) => {
  console.log(`🚖 Ride started by driver ${socket.data.driverId}`);
};

export const onRideComplete = (socket: Socket) => {
  console.log(`✅ Ride completed by driver ${socket.data.driverId}`);
};
