import { Socket } from "socket.io";

export const onDriverAuth = (socket: Socket, payload: { driverId: string }) => {
  socket.data.driverId = payload.driverId;
  socket.join(`driver:${payload.driverId}`);
  console.log(`✅ Driver ${payload.driverId} authenticated & joined room`);
};
