import { Socket } from "socket.io";
import { locationService } from "../../services/location.service";

export const onDriverLocationUpdate = async (
  socket: Socket,
  payload: { lat: number; lng: number }
) => {
  const driverId = socket.data.driverId;
  if (!driverId) return;

  const location = await locationService.set(driverId, payload.lat, payload.lng, Date.now());
  socket.nsp.server.of("/rider").to(`ride:${driverId}`).emit("driver:location:live", location);
};
