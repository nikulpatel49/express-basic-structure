import { Socket } from "socket.io";

export const onRideJoin = (socket: Socket, payload: { driverId: string }) => {
  const riderId = socket.data.riderId;
  if (!riderId) return;

  socket.join(`ride:${payload.driverId}`);
  console.log(`👤 Rider ${riderId} joined ride with driver ${payload.driverId}`);
};
