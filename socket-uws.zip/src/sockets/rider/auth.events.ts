import { Socket } from "socket.io";

export const onRiderAuth = (socket: Socket, payload: { riderId: string }) => {
  socket.data.riderId = payload.riderId;
  console.log(`✅ Rider ${payload.riderId} authenticated`);
};
