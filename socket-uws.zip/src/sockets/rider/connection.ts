import { Socket } from "socket.io";
import { onRiderAuth } from "./auth.events";
import { onRiderLocationUpdate } from "./location.events";
import { onRideJoin } from "./ride.events";

export const onRiderConnection = (socket: Socket) => {
  console.log("👤 Rider connected:", socket.id);

  socket.on("rider:connect", (payload) => onRiderAuth(socket, payload));
  socket.on("ride:join", (payload) => onRideJoin(socket, payload));
  socket.on("rider:location:update", (payload) => onRiderLocationUpdate(socket, payload));
};
