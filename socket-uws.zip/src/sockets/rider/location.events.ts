import { Socket } from "socket.io";

export const onRiderLocationUpdate = (socket: Socket, payload: { lat: number; lng: number }) => {
  const riderId = socket.data.riderId;
  if (!riderId) return;

  socket.nsp.server.of("/driver").to(`rider:${riderId}`).emit("rider:location:live", {
    riderId,
    ...payload,
    timestamp: Date.now(),
  });
};
