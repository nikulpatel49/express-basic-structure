import { Namespace } from "socket.io";
import { onDriverConnection } from "../sockets/driver/connection";

const driverGateway = (driverNamespace: Namespace) => {
  driverNamespace.on("connection", onDriverConnection);
};

export default driverGateway;
