import { Namespace } from "socket.io";
import { onRiderConnection } from "../sockets/rider/connection";

const riderGateway = (riderNamespace: Namespace) => {
  riderNamespace.on("connection", onRiderConnection);
};

export default riderGateway;
