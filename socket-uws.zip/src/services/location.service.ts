type Location = { lat: number; lng: number; timestamp: number };

const store = new Map<string, Location>();

export const locationService = {
  set: async (driverId: string, lat: number, lng: number, timestamp: number) => {
    const location = { lat, lng, timestamp };
    store.set(driverId, location);
    return location;
  },

  get: async (driverId: string) => {
    return store.get(driverId);
  },
};
