export const rideService = {
  start: (driverId: string, riderId: string) => {
    console.log(`🚀 Ride started: driver=${driverId}, rider=${riderId}`);
  },
  complete: (driverId: string, riderId: string) => {
    console.log(`✅ Ride completed: driver=${driverId}, rider=${riderId}`);
  },
};
