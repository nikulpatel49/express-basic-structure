const { io } = require("socket.io-client");
const socket = io("http://localhost:4000/driver", { path: "/ws" });

socket.on("connect", () => {
  console.log("🚖 Driver connected", socket.id);
  socket.emit("driver:connect", { driverId: "driver1" });

  setInterval(() => {
    socket.emit("driver:location:update", {
      lat: 12.9716 + Math.random() / 100,
      lng: 77.5946 + Math.random() / 100,
    });
  }, 5000);
});
