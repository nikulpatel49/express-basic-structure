import { Router } from "express";
import { register, login } from "../controllers/auth.controller";
import { validate } from "../middlewares/validate.middleware";
import { loginUserSchema, registerUserSchema } from "../schemas/user.schema";

const router = Router();

/**
 * @swagger
 * tags:
 *   name: Auth
 *   description: authentication
 */

/**
 * @swagger
 * /auth/register:
 *   post:
 *     summary: register a new user
 *     tags:
 *       - Auth
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *               - email
 *               - password
 *             properties:
 *               name:
 *                 type: string
 *                 example: nks
 *               password:
 *                 type: string
 *                 example: Password@$99
 *               email:
 *                 type: string
 *                 format: email
 *                 example: nks@example.com
 *     responses:
 *       200:
 *         description: User registered successfully
 *         content:
 *           application/json:
 *             example:
 *               statusCode: 200
 *               message: User registered successfully
 *               data:
 *                 user:
 *                   id: 661f1b23a2cd3a001efcb792
 *                   name: nks
 *                   email: nks@example.com
 *       400:
 *         description: Validation or duplicate email/username error
 *         content:
 *           application/json:
 *             example:
 *               statusCode: 400
 *               message: error message.
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             example:
 *               statusCode: 500
 *               message: Internal server error
 */
/**
 * @route POST /user:
 * @description Create a new user
 * @access Private
 */
router.post("/register", validate(registerUserSchema), register);

/**
 * @swagger
 * /auth/login:
 *   post:
 *     summary: Login user with email and password
 *     tags:
 *       - Auth
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - email
 *               - password
 *             properties:
 *               email:
 *                 type: string
 *                 format: email
 *                 example: nks@example.com
 *               password:
 *                 type: string
 *                 format: password
 *                 example: Password@$99
 *     responses:
 *       200:
 *         description: Successful login
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 statusCode:
 *                   type: integer
 *                   example: 200
 *                 data:
 *                   type: object
 *                   properties:
 *                     accessToken:
 *                       type: string
 *                       example: eyJhbGciOiJIUzI1NiIsInR5c
 *                     refreshToken:
 *                       type: string
 *                       example: eyJhbGciOiJIUzI1NiIsInR5c
 *                 message:
 *                   type: string
 *                   example: User successfully login.
 *       400:
 *         description: Invalid email or password
 *         content:
 *           application/json:
 *             example:
 *               statusCode: 400
 *               message: Invalid email or password
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             example:
 *               statusCode: 500
 *               message: Internal server error
 */
/**
 * @route POST /auth/login:
 * @description Login user
 * @access Private
 */
router.post("/login", validate(loginUserSchema), login);

export default router;
