// src/routes/swagger.ts
import { Router, Request, Response } from "express";
import swaggerUi from "swagger-ui-express";
import swaggerDocs from "../config/swagger.config"; // This must export a valid OpenAPI spec object

const router: Router = Router();

// Serve Swagger UI at root
router.use("/", swaggerUi.serve, swaggerUi.setup(swaggerDocs));

// Serve raw Swagger JSON at /json
router.get("/json", (req: Request, res: Response) => {
	res.status(200).json(swaggerDocs);
});

export default router;
