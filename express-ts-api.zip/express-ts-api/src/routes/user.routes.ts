import { Router } from "express";
import { getUsersHandler } from "../controllers/user.controller";

const router = Router();
/**
 * @swagger
 * tags:
 *   name: User
 *   description: Api for manage user. All routes under require `authentication` and are accessible after successful login.
 */

/**
 * @swagger
 * /user:
 *   get:
 *     summary: get all users
 *     tags:
 *       - User
 *     security:
 *       - BearerAuth: []
 *     responses:
 *       200:
 *         description: Success response
 *         content:
 *           application/json:
 *             example:
 *               statusCode: 200
 *               data: [{
 *       		  "name": "nks",
 *       		  "email": "nks@example.com",
 *       		  "createdAt": "2025-04-17T17:25:29.407Z"
 * 				 }]
 *               msg: message
 *       400:
 *         description: Error response
 *         content:
 *           application/json:
 *             example:
 *               statusCode: 400
 *               msg: error message.
 */

/**
 * @route GET  /user
 * @description get all users
 * @access Private
 */
router.get("/", getUsersHandler);

export default router;
