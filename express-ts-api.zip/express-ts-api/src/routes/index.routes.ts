import { Router, Request, Response } from "express";
import userRoutes from "./user.routes";
import authRoutes from "./auth.routes";
import swaggerRoutes from "./swagger.routes";
import { authenticateUser } from "../middlewares/authenticate.middleware";

const router: Router = Router();
if (process.env.NODE_ENV === "local") {
	router.use("/api-docs", swaggerRoutes);
}
router.use("/user", authenticateUser, userRoutes);
router.use("/auth", authRoutes);

router.get("/", (req: Request, res: Response) => {
	res.status(200).json({ message: "Welcome to the API!" });
});

export default router;
