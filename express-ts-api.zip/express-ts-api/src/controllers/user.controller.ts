import { Request, Response, NextFunction } from "express";
import * as authService from "../services/auth.service";
import * as userService from "../services/user.service";
import { CreateUserDto } from "../schemas/user.schema";
import { errorResponse, successResponse } from "../utils/apiResponse.utils";

export async function getUsersHandler(
	req: Request,
	res: Response
): Promise<Response> {
	try {
		const users = await userService.getUsers();
		return successResponse(res, users);
	} catch (err) {
		return errorResponse(res, err);
	}
}
