import { Request, Response } from "express";
import * as authService from "../services/auth.service";
import { errorResponse, successResponse } from "../utils/apiResponse.utils";

export const login = async (req: Request, res: Response): Promise<Response> => {
	const { email, password } = req.body;
	try {
		const result = await authService.login(email, password);
		if (result.status) {
			return successResponse(res, result.data);
		} else {
			return errorResponse(res, null, result.message, result.statusCode);
		}
	} catch (err) {
		return errorResponse(
			res,
			null,
			"Something went wrong, please try again!",
			500
		);
	}
};

export const register = async (
	req: Request,
	res: Response
): Promise<Response> => {
	try {
		const result = await authService.register(req.body);
		if (result.status) {
			return successResponse(res, result.data);
		} else {
			return errorResponse(res, null, result.message, result.statusCode);
		}
	} catch (err) {
		return errorResponse(
			res,
			null,
			"Something went wrong, please try again!",
			500
		);
	}
};
