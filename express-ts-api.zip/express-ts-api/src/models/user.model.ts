import mongoose, { Document, Model, Schema, Types } from "mongoose";
import { IUser } from "../interfaces/user.interface";
import { comparePassword, hashPassword } from "../utils/password.utils";

export interface IUserDocument extends IUser, Document {
	_id: Types.ObjectId;
	comparePassword(password: string): Promise<boolean>;
}

const UserSchema: Schema = new Schema<IUserDocument>(
	{
		name: { type: String, required: true },
		email: {
			type: String,
			trim: true,
			index: true,
			required: true,
			unique: true,
		},
		password: {
			type: String,
			required: true,
		},
		tokens: [
			{
				jwtId: { type: String },
				refreshToken: { type: String },
				tokenVersion: { type: Number },
				deviceInfo: { type: String },
				expiresAt: { type: Date },
			},
		],
	},
	{ timestamps: true }
);

// Pre-save hook
UserSchema.pre<IUserDocument>("save", async function (next) {
	try {
		if (!this.isModified("password")) return next();
		this.password = await hashPassword(this.password);
		next();
	} catch (err) {
		next(err as Error);
	}
});

UserSchema.pre("findOneAndUpdate", async function (next) {
	try {
		const update = this.getUpdate() as { password?: string };
		if (update?.password) {
			update.password = await hashPassword(update.password);
			this.setUpdate(update);
		}
		next();
	} catch (err) {
		next(err as Error);
	}
});

UserSchema.methods.comparePassword = async function (
	password: string
): Promise<boolean> {
	return await comparePassword(password, this.password);
};

export const UserModel: Model<IUserDocument> = mongoose.model<IUserDocument>(
	"User",
	UserSchema
);
