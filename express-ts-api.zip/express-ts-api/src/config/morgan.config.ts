export const morganLogFormat =
	":method :url :status :res[content-length] - :response-time ms :error :res[content]";

export const morganLogDir = process.env.LOG_DIR || "/logs";
export const morganLogFormatWithError =
	":method :url :status :res[content-length] - :response-time ms :error :res[content]";
