import mongoose from "mongoose";
import { logger } from "../utils/logger.utils";
const MONGO_URI = process.env.MONGO_URI || "mongodb://localhost:27017/mydb";
export const connectMongoDB = async (): Promise<void> => {
	try {
		await mongoose.connect(MONGO_URI, {});
		logger.info("Database connected successfully");
	} catch (error) {
		logger.error("Database connection failed:", error);
		process.exit(1);
	}
};
