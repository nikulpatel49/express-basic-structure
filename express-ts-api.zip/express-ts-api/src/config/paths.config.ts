import path from "path";
import { morganLogDir } from "./morgan.config";

export const ROOT_DIR = process.cwd();
export const SRC_DIR = path.join(ROOT_DIR, "src");
export const LOGS_DIR = path.join(ROOT_DIR, "logs");
export const MORGAN_LOGS_DIR = path.join(ROOT_DIR, morganLogDir);
