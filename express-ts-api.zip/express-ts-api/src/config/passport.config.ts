import { PassportStatic } from "passport";
import {
	Strategy as JwtStrategy,
	ExtractJwt,
	StrategyOptions,
} from "passport-jwt";
import { Strategy as HeaderStrategy } from "passport-http-header-strategy";
import { Request } from "express";
import { UserModel, IUserDocument } from "../models/user.model";

const JWT_ACCESS_SECRET_KEY = process.env.JWT_ACCESS_SECRET_KEY!;
const X_API_KEY = process.env.X_API_KEY!;

interface JwtPayload {
	[key: string]: any;
}

export default (passport: PassportStatic): void => {
	// JWT Strategy Options
	const jwtOptions: StrategyOptions = {
		jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
		secretOrKey: JWT_ACCESS_SECRET_KEY,
	};

	// JWT Strategy
	passport.use(
		"user-jwt-auth",
		new JwtStrategy(
			jwtOptions,
			async (jwtPayload: JwtPayload, done: any) => {
				console.log("🚀 ~ jwtPayload:", jwtPayload);
				try {
					if (jwtPayload?._id) {
						const user: IUserDocument | null =
							await UserModel.findById(jwtPayload._id).lean();
						if (user) {
							const [token] = user.tokens;
							if (
								token.tokenVersion === jwtPayload.tokenVersion
							) {
								return done(null, { user });
							} else {
								return done(null, false);
							}
						} else {
							return done(null, false);
						}
					}
					return done(null, false);
				} catch (error) {
					return done(error as Error, false);
				}
			}
		)
	);

	// API Key Strategy
	passport.use(
		"x-apikey-authentication",
		new HeaderStrategy(
			{ header: "X-API-KEY", passReqToCallback: true },
			(req: Request, token: string, done: any) => {
				if (X_API_KEY === token) {
					return done(null, true);
				}
				return done(null, false);
			}
		)
	);
};
