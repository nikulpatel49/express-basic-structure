import swaggerJsDoc from "swagger-jsdoc";
import { OpenAPIV3 } from "openapi-types";
const { API_NAME, PORT } = process.env;

const swaggerDefinition: OpenAPIV3.Document = {
	openapi: "3.0.0",
	info: {
		title: API_NAME || "API Documentation",
		version: "1.0.0",
		description: `${API_NAME} API docs`,
	},
	servers: [
		{
			url: `http://localhost:${PORT || 3000}`,
		},
	],
	components: {
		securitySchemes: {
			ApiKeyAuth: {
				type: "apiKey",
				in: "header",
				name: "x-api-key",
			},
			BearerAuth: {
				type: "http",
				scheme: "bearer",
				bearerFormat: "JWT",
			},
		},
	},
	security: [{ ApiKeyAuth: [] }, { BearerAuth: [] }],
	paths: {},
};

const swaggerOptions = {
	swaggerDefinition,
	apis: ["./src/routes/**/*.ts"],
};

const swaggerDocs = swaggerJsDoc(swaggerOptions);
export default swaggerDocs;
