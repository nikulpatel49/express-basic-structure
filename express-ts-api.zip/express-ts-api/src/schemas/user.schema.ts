import { z } from "zod";

const strongPasswordRegex =
	/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

export const registerUserSchema = z.object({
	body: z.object({
		name: z.string().min(1, "Name is required"),
		email: z.string().email("Invalid email format"),
		password: z
			.string()
			.min(8, { message: "Password must be at least 8 characters long" })
			.regex(strongPasswordRegex, {
				message:
					"Password must include uppercase, lowercase, number, and special character",
			}),
	}),
});

export const loginUserSchema = z.object({
	body: z.object({
		email: z.string().email("Invalid email format"),
		password: z.string().min(1, "Password is required"),
	}),
});

export type CreateUserDto = z.infer<typeof registerUserSchema>;
