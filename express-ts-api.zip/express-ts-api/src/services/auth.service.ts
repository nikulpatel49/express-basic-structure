import { UserModel } from "../models/user.model";
import {
	generateAccessToken,
	generateRefreshToken,
	verifyRefreshToken,
} from "../utils/jwt.utils";
import { CreateUserDto } from "../schemas/user.schema";
import _ from "lodash";

export const register = async (data: CreateUserDto): Promise<any> => {
	try {
		const user = new UserModel({
			...data,
		});
		const result = await user.save();
		return {
			status: true,
			data: {
				name: result.name,
				email: result.email,
			},
		};
	} catch (error: any) {
		if (error.code === 11000) {
			const field = Object.keys(error.keyValue)?.[0];
			error.message = `${field} already exists.`;
		}
		return { status: false, message: error.message };
	}
};

export const login = async (email: string, password: string): Promise<any> => {
	try {
		const user = await UserModel.findOne({ email });
		if (!user) {
			return {
				status: false,
				statusCode: 401,
				message: "Invalid credentials",
			};
		}
		const isMatchPassword = user.comparePassword(password);
		if (!isMatchPassword) {
			return {
				status: false,
				statusCode: 401,
				message: "Invalid credentials",
			};
		}
		let [token = null, ...__] = user.tokens;
		token = token
			? { ...token, tokenVersion: (token.tokenVersion ?? 0) + 1 }
			: { refreshToken: "", expiresAt: new Date(), tokenVersion: 1 };
		const payload = {
			_id: user._id.toString(),
			name: user.name,
			email: email,
			tokenVersion: token.tokenVersion,
		};
		const accessToken = generateAccessToken(payload);
		const refreshToken = generateRefreshToken(payload);
		token.expiresAt = new Date();
		token.refreshToken = refreshToken;
		user.tokens = [token];
		await user.save();
		return {
			status: true,
			data: { accessToken: accessToken, refreshToken: refreshToken },
		};
	} catch (error: any) {
		console.error(error);
		return { status: false, message: error.message };
	}
};

export const refresh = async (refreshToken: string): Promise<any> => {
	try {
		if (_.isEmpty(refreshToken)) {
			return {
				status: false,
				statusCode: 401,
				message: "Invalid refreshToken",
			};
		}
		const userDetails = verifyRefreshToken(refreshToken);
		const user = await UserModel.findOne({ _id: userDetails?._id });
		if (!user) {
			return {
				status: false,
				statusCode: 401,
				message: "Invalid refreshToken",
			};
		}
		const tokenExists = user.tokens.some(
			(rt) => rt.refreshToken === refreshToken
		);
		if (!tokenExists)
			return {
				status: false,
				statusCode: 401,
				message: "Invalid refreshToken",
			};
		let [token = null, ...__] = user.tokens;
		token = token
			? { ...token, tokenVersion: (token.tokenVersion ?? 0) + 1 }
			: { refreshToken: "", expiresAt: new Date(), tokenVersion: 1 };

		const payload = {
			_id: user._id.toString(),
			name: user.name,
			email: user.name,
			tokenVersion: token.tokenVersion,
		};
		const accessToken = generateAccessToken(payload);
		user.tokens = [token];
		await user.save();
		return {
			status: true,
			data: { accessToken: accessToken },
		};
	} catch (error: any) {
		console.error(error);
		return { status: false, message: error.message };
	}
};
