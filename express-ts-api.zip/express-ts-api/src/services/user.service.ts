import { UserModel, IUserDocument } from "../models/user.model";
import { CreateUserDto } from "../schemas/user.schema";

export const createUser = async (
	data: CreateUserDto
): Promise<IUserDocument> => {
	const user = new UserModel(data);
	return await user.save();
};

export const getUsers = async (): Promise<IUserDocument[]> => {
	return await UserModel.find();
};
