import { existsSync, mkdirSync } from "fs";
import { join } from "path";
import { createLogger, format, transports, Logger } from "winston";
import DailyRotateFile from "winston-daily-rotate-file";
import { MORGAN_LOGS_DIR } from "../config/paths.config";
// Setup log directory
const logDirPath: string = MORGAN_LOGS_DIR;
if (!existsSync(logDirPath)) {
	mkdirSync(logDirPath, { recursive: true });
}

const logFormat = format.printf(
	({ timestamp, level, message }) => `${timestamp} ${level}: ${message}`
);

// Winston Logger instance
const logger: Logger = createLogger({
	format: format.combine(
		format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
		logFormat
	),
	transports: [
		new DailyRotateFile({
			level: "debug",
			datePattern: "YYYY-MM-DD",
			dirname: join(logDirPath, "debug"),
			filename: "%DATE%.log",
			maxFiles: "30d",
			zippedArchive: true,
		}),
		new DailyRotateFile({
			level: "error",
			datePattern: "YYYY-MM-DD",
			dirname: join(logDirPath, "error"),
			filename: "%DATE%.log",
			maxFiles: "30d",
			handleExceptions: true,
			zippedArchive: true,
		}),
	],
});

// Add console logger
logger.add(
	new transports.Console({
		format: format.combine(format.splat(), format.colorize()),
	})
);

// Stream for morgan
export const stream = {
	write: (message: string): void => {
		logger.info(message.substring(0, message.lastIndexOf("\n")));
	},
};

export { logger };
