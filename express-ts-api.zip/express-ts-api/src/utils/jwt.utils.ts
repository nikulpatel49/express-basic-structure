import jwt, { JwtPayload, SignOptions } from "jsonwebtoken";

// Replace with your own validation function
const validateExpiresIn = (
	value: string | undefined,
	fallback: string
): any => {
	const regex = /^[1-9][0-9]*[smhdy]$/;
	const expiresIn = value || fallback;
	if (!regex.test(expiresIn))
		throw new Error(`Invalid expiresIn value: ${expiresIn}`);
	return expiresIn;
};

const JWT_ACCESS_SECRET_KEY = process.env.JWT_ACCESS_SECRET_KEY!;
const JWT_REFRESH_SECRET_KEY = process.env.JWT_REFRESH_SECRET_KEY!;

export interface TokenPayload extends JwtPayload {
	[key: string]: any;
}

export const generateAccessToken = (payload: TokenPayload): string => {
	const JWT_ACCESS_EXPIRES_IN = validateExpiresIn(
		process.env.JWT_ACCESS_EXPIRES_IN,
		"15m"
	);
	const options: SignOptions = { expiresIn: JWT_ACCESS_EXPIRES_IN };
	return jwt.sign(payload, JWT_ACCESS_SECRET_KEY, options);
};

export const generateRefreshToken = (payload: TokenPayload): string => {
	const JWT_REFRESH_EXPIRES_IN = validateExpiresIn(
		process.env.JWT_REFRESH_EXPIRES_IN,
		"30d"
	);
	const options: SignOptions = { expiresIn: JWT_REFRESH_EXPIRES_IN };
	return jwt.sign(payload, JWT_REFRESH_SECRET_KEY, options);
};

export const verifyAccessToken = (token: string): TokenPayload | null => {
	try {
		const decoded = jwt.verify(token, JWT_ACCESS_SECRET_KEY);
		return decoded as TokenPayload;
	} catch (error) {
		console.error("Access Token Verification Failed:", error);
		return null;
	}
};

export const verifyRefreshToken = (token: string): TokenPayload | null => {
	try {
		const decoded = jwt.verify(token, JWT_REFRESH_SECRET_KEY);
		return decoded as TokenPayload;
	} catch (error) {
		console.error("Refresh Token Verification Failed:", error);
		return null;
	}
};
