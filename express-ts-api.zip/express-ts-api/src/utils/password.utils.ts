import argon2 from "argon2";
const PASSWORD_HASHING_KEY = process.env.PASSWORD_HASHING_KEY;

if (!PASSWORD_HASHING_KEY) {
	throw new Error(
		"PASSWORD_HASHING_KEY is not defined in environment variables."
	);
}

export const hashPassword = async (password: string): Promise<string> => {
	return await argon2.hash(password, {
		secret: Buffer.from(PASSWORD_HASHING_KEY),
	});
};

export const comparePassword = async (
	password: string,
	hashedPassword: string
): Promise<boolean> => {
	return await argon2.verify(hashedPassword, password, {
		secret: Buffer.from(PASSWORD_HASHING_KEY),
	});
};
