import { Response } from "express";

export const successResponse = <T>(
	res: Response,
	data: T,
	message: string = "Success",
	statusCode: number = 200
): Response => {
	return res.status(statusCode).json({
		statusCode,
		data,
		message: message,
	});
};

export const errorResponse = (
	res: Response,
	error: unknown,
	message: string = "Internal Server Error",
	statusCode: number = 500
): Response => {
	return res.status(statusCode).json({
		statusCode,
		error: parseError(error),
		message: message,
	});
};

const parseError = (error: unknown): string | Record<string, unknown> => {
	if (error instanceof Error) {
		return error.message;
	}
	if (typeof error === "object" && error !== null) {
		return error as Record<string, unknown>;
	}
	return String(error);
};

export const badRequestResponse = (
	res: Response,
	error: unknown,
	message: string = "Bad Request"
): Response => errorResponse(res, error, message, 400);

export const unauthorizedResponse = (
	res: Response,
	error: unknown,
	message: string = "Unauthorized"
): Response => errorResponse(res, error, message, 401);

export const forbiddenResponse = (
	res: Response,
	error: unknown,
	message: string = "Forbidden"
): Response => errorResponse(res, error, message, 403);

export const notFoundResponse = (
	res: Response,
	error: unknown,
	message: string = "Not Found"
): Response => errorResponse(res, error, message, 404);

export const conflictResponse = (
	res: Response,
	error: unknown,
	message: string = "Conflict"
): Response => errorResponse(res, error, message, 409);

export const unprocessableEntityResponse = (
	res: Response,
	error: unknown,
	message: string = "Unprocessable Entity"
): Response => errorResponse(res, error, message, 422);
