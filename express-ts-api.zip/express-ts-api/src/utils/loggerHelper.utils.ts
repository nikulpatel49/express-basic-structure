import { Request, Response } from "express";
const sensitiveKeysList: string[] = [
	"password",
	"passwords",
	"oldPassword",
	"newPassword",
	"token",
	"secret",
	"apiKey",
	"accessToken",
];

export const redactLogData = (data: unknown): unknown => {
	if (
		typeof data === "object" &&
		data !== null &&
		!(data instanceof Buffer)
	) {
		if (Array.isArray(data)) {
			return data.map((item) => redactLogData(item));
		}

		const redacted: Record<string, unknown> = {};
		for (const [key, value] of Object.entries(data)) {
			redacted[key] = sensitiveKeysList.includes(key)
				? "*****"
				: redactLogData(value);
		}
		return redacted;
	}
	return data;
};

/**
 * Generates structured log data for failed requests (>= 400).
 * @param req Express Request object
 * @param res Express Response object
 * @returns JSON string or null
 */
export const getMorganErrorLog = (
	req: Request,
	res: Response
): string | undefined => {
	try {
		if (res.statusCode >= 400) {
			const logPayload = {
				request: {
					method: req.method,
					url: req.originalUrl,
					params: req.params,
					query: req.query,
					body: redactLogData(req.body),
					userId: (req as any).user?._id || null, // Extend this as needed
				},
				response: {
					statusCode: res.statusCode,
					statusMessage: res.statusMessage,
					errorData: (res as any).errorData || null,
					user: (res as any).user || null,
				},
				timestamp: new Date().toISOString(),
			};
			return JSON.stringify(logPayload, null, 2);
		}
		return undefined;
	} catch (err) {
		return undefined;
	}
};
