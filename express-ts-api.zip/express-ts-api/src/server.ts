import dotenv from "dotenv";
dotenv.config();

import { connectMongoDB } from "./config/mongoDB.config";
import { logger } from "./utils/logger.utils";
import app from "./app";

const PORT: number = parseInt(process.env.PORT || "5000", 10);
const startServer = async (): Promise<void> => {
	try {
		await connectMongoDB();
		app.listen(PORT, () => {
			logger.info(`Server running on http://localhost:${PORT}`);
		});
	} catch (error) {
		logger.error("Failed to start server:", error);
		process.exit(1); // Exit on failure
	}
};
startServer();
