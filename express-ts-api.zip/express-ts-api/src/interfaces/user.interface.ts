export interface IUser {
	name: string;
	email: string;
	password: string;
	tokens: [
		{
			jwtId?: string;
			refreshToken?: string;
			tokenVersion?: number;
			deviceInfo?: string;
			expiresAt: Date;
		}
	];
}
