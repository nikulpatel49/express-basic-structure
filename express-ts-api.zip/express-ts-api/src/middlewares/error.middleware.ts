import { Request, Response, NextFunction } from "express";
import { logger } from "../utils/logger.utils";

export const errorHandler = (
	err: unknown,
	req: Request,
	res: Response
): Response | void => {
	try {
		const statusCode =
			(err as any)?.status || (err as any)?.httpCode || 500;
		const message = (err as any)?.message || "Something went wrong";
		const stack = (err as any)?.stack;
		logger.error(
			`[${req.method}] ${req.originalUrl} | ${statusCode} | ${message}`
		);
		if (stack) logger.debug(`Stack trace: ${stack}`);
		res.locals.errorData = {
			message,
			stack,
		};
		return res.status(statusCode).json({
			statusCode,
			error: message,
			path: req.originalUrl,
			timestamp: new Date().toISOString(),
		});
	} catch (internalError) {
		logger.error("Error in errorHandler:", internalError);
		return res.status(500).json({
			statusCode: 500,
			error: "Critical failure in error handler",
		});
	}
};
