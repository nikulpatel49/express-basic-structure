import passport from "passport";
import { Request, Response, NextFunction } from "express";
import { unauthorizedResponse } from "../utils/apiResponse.utils";
import { IUserDocument } from "../models/user.model"; // Make sure this interface exists
import _ from "lodash";

export const authenticateUser = (
	req: Request,
	res: Response,
	next: NextFunction
): void => {
	passport.authenticate(
		"user-jwt-auth",
		(err: any, data: { user?: IUserDocument } | false) => {
			if (err) return next(err);

			if (!data || _.isEmpty(data.user)) {
				return unauthorizedResponse(res, {}, "Unauthorized user");
			}
			req.user = data.user;
			return next();
		}
	)(req, res, next);
};
