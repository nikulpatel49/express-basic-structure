import morgan, { StreamOptions } from "morgan";
import { logger, stream } from "../utils/logger.utils";
const morganMiddleware = morgan("combined", {
	stream: stream as StreamOptions,
});

export default morganMiddleware;
