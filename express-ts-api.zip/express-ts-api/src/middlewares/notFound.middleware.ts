import { Request, Response } from "express";
import { notFoundResponse } from "../utils/apiResponse.utils";

export function notFoundHandler(req: Request, res: Response): Response {
	return notFoundResponse(res, {});
}
