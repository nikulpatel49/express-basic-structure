import express from "express";
import { errorHandler } from "./middlewares/error.middleware";
import { notFoundHandler } from "./middlewares/notFound.middleware";
import morganMiddleware from "./middlewares/morganLogger.middleware";
import morgan from "morgan";
import { getMorganErrorLog } from "./utils/loggerHelper.utils";
import routes from "./routes/index.routes";
import passport from "passport";
import configPassport from "./config/passport.config";

const app = express();
app.use(express.json());
app.use(passport.initialize());
configPassport(passport);
morgan.token("error", getMorganErrorLog);
app.use(morganMiddleware);
app.use("/", routes);
app.use(notFoundHandler);
app.use(errorHandler);

export default app;
